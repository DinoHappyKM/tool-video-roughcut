﻿param([string]$ProjectDirectory = $PSScriptRoot)
$ErrorActionPreference = 'Stop'
function Read-FileSha256([string]$FilePath) {
    $stream = [IO.File]::OpenRead($FilePath)
    $algorithm = [Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($algorithm.ComputeHash($stream)) }
    finally { $stream.Dispose(); $algorithm.Dispose() }
}
$source = Join-Path $PSScriptRoot 'payload\video-production-pilot'
$project = [IO.Path]::GetFullPath($ProjectDirectory)
$target = Join-Path $project '.agents\skills\video-production-pilot'
if (-not (Test-Path -LiteralPath (Join-Path $source 'SKILL.md'))) { throw '找不到完整 payload，請先解壓縮。' }
$files = @(Get-ChildItem -LiteralPath $source -File -Recurse)
foreach ($file in $files) {
    $relative = $file.FullName.Substring($source.Length).TrimStart('\','/')
    $dest = Join-Path $target $relative
    if (Test-Path -LiteralPath $dest) {
        if (-not (Test-Path -LiteralPath $dest -PathType Leaf)) { throw "目的地不是檔案：$dest" }
        if ((Read-FileSha256 $dest) -ne (Read-FileSha256 $file.FullName)) { throw "已有不同內容，保留原檔；請先備份或指定另一個專案：$dest" }
    }
}
foreach ($file in $files) {
    $relative = $file.FullName.Substring($source.Length).TrimStart('\','/')
    $dest = Join-Path $target $relative
    if (-not (Test-Path -LiteralPath $dest)) {
        [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($dest)) | Out-Null
        Copy-Item -LiteralPath $file.FullName -Destination $dest
    }
    if ((Read-FileSha256 $dest) -ne (Read-FileSha256 $file.FullName)) { throw "安裝驗證失敗：$dest" }
}
Write-Output "已安裝影片技能檔案：$target"
Write-Output '在 Codex 打開此專案，請使用 $video-production-pilot；原生發現與 ChatCut 連線仍須實測。'
