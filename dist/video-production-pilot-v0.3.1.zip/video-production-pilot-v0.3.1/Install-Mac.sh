#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
SOURCE_DIR="$SCRIPT_DIR/payload/video-production-pilot"
PROJECT_DIR="${1:-$SCRIPT_DIR}"
TARGET_DIR="$PROJECT_DIR/.agents/skills/video-production-pilot"
if [[ ! -f "$SOURCE_DIR/SKILL.md" ]]; then
  echo "找不到完整 payload，請先解壓縮。" >&2
  exit 1
fi
while IFS= read -r -d '' file; do
  relative="${file#"$SOURCE_DIR"/}"
  dest="$TARGET_DIR/$relative"
  if [[ -e "$dest" ]]; then
    if [[ ! -f "$dest" ]] || ! cmp -s "$file" "$dest"; then
      echo "已有不同內容，保留原檔；請先備份或指定另一個專案：$dest" >&2
      exit 1
    fi
  fi
done < <(find "$SOURCE_DIR" -type f -print0)
while IFS= read -r -d '' file; do
  relative="${file#"$SOURCE_DIR"/}"
  dest="$TARGET_DIR/$relative"
  mkdir -p -- "$(dirname -- "$dest")"
  if [[ ! -e "$dest" ]]; then cp -- "$file" "$dest"; fi
  cmp -s "$file" "$dest" || { echo "安裝驗證失敗：$dest" >&2; exit 1; }
done < <(find "$SOURCE_DIR" -type f -print0)
printf '已安裝影片技能檔案：%s\n' "$TARGET_DIR"
echo '在 Codex 打開此專案，請使用 $video-production-pilot；原生發現與 ChatCut 連線仍須實測。'
